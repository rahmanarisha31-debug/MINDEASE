/**
 * Procedural ambient sound generation using Web Audio API.
 * Only used on Expo web — native uses expo-av with bundled/remote files.
 *
 * Each generator returns a `stop()` function to clean up nodes.
 */

type Ctx = AudioContext;

// ── Helpers ──────────────────────────────────────────────────────────────────

function getAudioContext(): Ctx | null {
  if (typeof window === "undefined") return null;
  const Ctor =
    (window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext })
      .AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  return new Ctor();
}

/** Build a stereo pink-noise buffer (Voss algorithm). */
function makePinkNoiseBuffer(ctx: Ctx, seconds = 6): AudioBuffer {
  const len = ctx.sampleRate * seconds;
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + w * 0.0555179;
      b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.96900 * b2 + w * 0.1538520;
      b3 = 0.86650 * b3 + w * 0.3104856;
      b4 = 0.55000 * b4 + w * 0.5329522;
      b5 = -0.7616 * b5 - w * 0.0168980;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
      b6 = w * 0.115926;
    }
  }
  return buf;
}

/** Build a stereo brown-noise buffer. */
function makeBrownNoiseBuffer(ctx: Ctx, seconds = 6): AudioBuffer {
  const len = ctx.sampleRate * seconds;
  const buf = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02;
      d[i] = last * 3.5; // scale up
    }
  }
  return buf;
}

// ── Rain ─────────────────────────────────────────────────────────────────────
// Pink noise through a gentle low-pass filter, plus a very subtle high-freq
// shimmer to mimic droplet texture.

export function startRain(volume = 0.7): () => void {
  const ctx = getAudioContext();
  if (!ctx) return () => {};

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0, ctx.currentTime);
  masterGain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 1.5);
  masterGain.connect(ctx.destination);

  // Main pink noise body
  const pinkBuf = makePinkNoiseBuffer(ctx, 8);
  const pinkSrc = ctx.createBufferSource();
  pinkSrc.buffer = pinkBuf;
  pinkSrc.loop = true;
  pinkSrc.loopEnd = pinkBuf.duration;

  const lpf = ctx.createBiquadFilter();
  lpf.type = "lowpass";
  lpf.frequency.value = 1800;
  lpf.Q.value = 0.5;

  pinkSrc.connect(lpf);
  lpf.connect(masterGain);
  pinkSrc.start();

  // High-freq shimmer (droplet texture)
  const shimmerBuf = makePinkNoiseBuffer(ctx, 4);
  const shimmerSrc = ctx.createBufferSource();
  shimmerSrc.buffer = shimmerBuf;
  shimmerSrc.loop = true;

  const hpf = ctx.createBiquadFilter();
  hpf.type = "highpass";
  hpf.frequency.value = 4000;
  hpf.Q.value = 1.0;

  const shimmerGain = ctx.createGain();
  shimmerGain.gain.value = 0.18;

  shimmerSrc.connect(hpf);
  hpf.connect(shimmerGain);
  shimmerGain.connect(masterGain);
  shimmerSrc.start();

  return () => {
    masterGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.2);
    setTimeout(() => {
      try { pinkSrc.stop(); shimmerSrc.stop(); ctx.close(); } catch (_) {}
    }, 1400);
  };
}

// ── Ocean ─────────────────────────────────────────────────────────────────────
// Brown noise (deeper rumble) with a slow 0.07 Hz AM modulation to create
// the swelling wave rhythm.

export function startOcean(volume = 0.7): () => void {
  const ctx = getAudioContext();
  if (!ctx) return () => {};

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0, ctx.currentTime);
  masterGain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 2);
  masterGain.connect(ctx.destination);

  const brownBuf = makeBrownNoiseBuffer(ctx, 8);
  const src = ctx.createBufferSource();
  src.buffer = brownBuf;
  src.loop = true;

  // Band-pass for ocean rumble character
  const bpf = ctx.createBiquadFilter();
  bpf.type = "bandpass";
  bpf.frequency.value = 300;
  bpf.Q.value = 0.4;

  // Slow AM oscillator (wave rhythm ~14 sec per wave)
  const lfo = ctx.createOscillator();
  lfo.type = "sine";
  lfo.frequency.value = 0.07;

  const lfoGain = ctx.createGain();
  lfoGain.gain.value = 0.4;

  const waveShapeGain = ctx.createGain();
  waveShapeGain.gain.value = 0.6;

  src.connect(bpf);
  bpf.connect(waveShapeGain);

  lfo.connect(lfoGain);
  lfoGain.connect(waveShapeGain.gain);

  waveShapeGain.connect(masterGain);
  src.start();
  lfo.start();

  return () => {
    masterGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.5);
    setTimeout(() => {
      try { src.stop(); lfo.stop(); ctx.close(); } catch (_) {}
    }, 1700);
  };
}

// ── Forest ───────────────────────────────────────────────────────────────────
// Soft green-noise bed (mid-freq filtered pink) + a handful of AM-modulated
// sine oscillators pitched like distant bird calls.

const BIRD_FREQS = [880, 1320, 2200, 1760, 3300];

export function startForest(volume = 0.65): () => void {
  const ctx = getAudioContext();
  if (!ctx) return () => {};

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0, ctx.currentTime);
  masterGain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 1.8);
  masterGain.connect(ctx.destination);

  // Green noise bed
  const pinkBuf = makePinkNoiseBuffer(ctx, 8);
  const noiseSrc = ctx.createBufferSource();
  noiseSrc.buffer = pinkBuf;
  noiseSrc.loop = true;

  const bpf = ctx.createBiquadFilter();
  bpf.type = "bandpass";
  bpf.frequency.value = 700;
  bpf.Q.value = 0.7;

  const noiseGain = ctx.createGain();
  noiseGain.gain.value = 0.55;

  noiseSrc.connect(bpf);
  bpf.connect(noiseGain);
  noiseGain.connect(masterGain);
  noiseSrc.start();

  // Bird call oscillators
  const osc: OscillatorNode[] = [];
  BIRD_FREQS.forEach((freq, i) => {
    const carrier = ctx.createOscillator();
    carrier.type = "sine";
    carrier.frequency.value = freq;

    const lfo = ctx.createOscillator();
    lfo.type = "sine";
    lfo.frequency.value = 4 + i * 0.7; // ~4-7 Hz trill

    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.5;

    const birdGain = ctx.createGain();
    birdGain.gain.value = 0;

    // Schedule bird calls randomly
    const callGain = ctx.createGain();
    callGain.gain.value = 0.022;

    lfo.connect(lfoGain);
    lfoGain.connect(birdGain.gain);
    carrier.connect(birdGain);
    birdGain.connect(callGain);
    callGain.connect(masterGain);

    // Schedule chirps: random bursts every 5-20 seconds
    const scheduleChirp = () => {
      const now = ctx.currentTime;
      const delay = 2 + Math.random() * 14;
      const dur = 0.3 + Math.random() * 0.8;
      birdGain.gain.setValueAtTime(0, now + delay);
      birdGain.gain.linearRampToValueAtTime(1, now + delay + 0.04);
      birdGain.gain.setValueAtTime(1, now + delay + dur);
      birdGain.gain.linearRampToValueAtTime(0, now + delay + dur + 0.06);
    };

    // Schedule several bursts up front
    for (let j = 0; j < 20; j++) scheduleChirp();

    carrier.start();
    lfo.start();
    osc.push(carrier, lfo);
  });

  return () => {
    masterGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.5);
    setTimeout(() => {
      try { noiseSrc.stop(); osc.forEach((o) => o.stop()); ctx.close(); } catch (_) {}
    }, 1700);
  };
}

// ── Meditation bowls (bonus gentle tone) ─────────────────────────────────────
// Harmonic sine tones at 432 Hz and its overtones with slow fade-in.

export function startBowls(volume = 0.55): () => void {
  const ctx = getAudioContext();
  if (!ctx) return () => {};

  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0, ctx.currentTime);
  masterGain.gain.linearRampToValueAtTime(volume, ctx.currentTime + 3);
  masterGain.connect(ctx.destination);

  const harmonics = [432, 864, 1296, 528];
  const gains =     [1.0, 0.3,  0.15, 0.4];

  harmonics.forEach((freq, i) => {
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;

    // Slow vibrato
    const lfo = ctx.createOscillator();
    lfo.type = "sine";
    lfo.frequency.value = 0.3;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = freq * 0.003;
    lfo.connect(lfoGain);
    lfoGain.connect(osc.frequency);

    const g = ctx.createGain();
    g.gain.value = gains[i] * 0.08;
    osc.connect(g);
    g.connect(masterGain);

    osc.start();
    lfo.start();
  });

  return () => {
    masterGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 2);
    setTimeout(() => { try { ctx.close(); } catch (_) {} }, 2500);
  };
}

export type AmbientGenerator = typeof startRain;
export const WEB_GENERATORS: Record<string, AmbientGenerator> = {
  rain: startRain,
  ocean: startOcean,
  forest: startForest,
  bowls: startBowls,
};
