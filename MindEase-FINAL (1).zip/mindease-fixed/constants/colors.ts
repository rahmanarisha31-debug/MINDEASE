const colors = {
  light: {
    text: "#1a1a1a",
    tint: "#1D9E75",

    background: "#F8F7F4",
    foreground: "#1a1a1a",

    card: "#FFFFFF",
    cardForeground: "#1a1a1a",

    primary: "#1D9E75",
    primaryForeground: "#FFFFFF",
    primaryLight: "#E1F5EE",
    primaryDark: "#085041",

    secondary: "#F0F0EE",
    secondaryForeground: "#1a1a1a",

    muted: "#F0F0EE",
    mutedForeground: "#6b6b6b",

    accent: "#7F77DD",
    accentForeground: "#FFFFFF",
    accentLight: "#EEEDFE",
    accentDark: "#3C3489",

    destructive: "#E24B4A",
    destructiveForeground: "#FFFFFF",
    destructiveLight: "#FCEBEB",

    amber: "#EF9F27",
    amberLight: "#FAEEDA",

    coral: "#D85A30",
    coralLight: "#FAECE7",

    border: "rgba(0,0,0,0.08)",
    input: "#E5E5E0",
    surface: "#FFFFFF",
  },

  dark: {
    text: "#F0EFEC",
    tint: "#2DBF8F",

    background: "#111210",
    foreground: "#F0EFEC",

    card: "#1C1E1B",
    cardForeground: "#F0EFEC",

    primary: "#2DBF8F",
    primaryForeground: "#FFFFFF",
    primaryLight: "#0D3027",
    primaryDark: "#A8EDD5",

    secondary: "#252724",
    secondaryForeground: "#F0EFEC",

    muted: "#252724",
    mutedForeground: "#8A8A8A",

    accent: "#9D96E8",
    accentForeground: "#FFFFFF",
    accentLight: "#1E1C3A",
    accentDark: "#C9C6F5",

    destructive: "#F06B6A",
    destructiveForeground: "#FFFFFF",
    destructiveLight: "#2D1515",

    amber: "#F5B042",
    amberLight: "#2E2010",

    coral: "#E8724A",
    coralLight: "#2D1509",

    border: "rgba(255,255,255,0.1)",
    input: "#2A2C29",
    surface: "#1C1E1B",
  },

  radius: 16,
};

export default colors;
