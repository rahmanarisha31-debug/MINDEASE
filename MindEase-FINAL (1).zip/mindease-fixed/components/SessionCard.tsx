import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/useColors";

export interface Session {
  id: string;
  tag: string;
  title: string;
  duration: string;
  durationMins: number;
  description: string;
  script: string;
  tagColor: string;
  tagBg: string;
}

interface Props {
  session: Session;
  onPress: (session: Session) => void;
}

export function SessionCard({ session, onPress }: Props) {
  const colors = useColors();
  const r = (colors as any).radius ?? 16;

  return (
    <TouchableOpacity
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: r,
        },
      ]}
      onPress={() => onPress(session)}
      activeOpacity={0.75}
    >
      <View style={styles.top}>
        <View
          style={[
            styles.tag,
            { backgroundColor: session.tagBg, borderRadius: 99 },
          ]}
        >
          <Text style={[styles.tagText, { color: session.tagColor }]}>
            {session.tag}
          </Text>
        </View>
        <Text style={[styles.duration, { color: colors.mutedForeground }]}>
          {session.duration}
        </Text>
      </View>
      <Text style={[styles.title, { color: colors.foreground }]}>
        {session.title}
      </Text>
      <Text style={[styles.desc, { color: colors.mutedForeground }]} numberOfLines={2}>
        {session.description}
      </Text>
      <View style={styles.footer}>
        <Feather name="play-circle" size={14} color={colors.primary} />
        <Text style={[styles.play, { color: colors.primary }]}>Start</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 18,
    borderWidth: 1,
    gap: 6,
  },
  top: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 2,
  },
  tag: {
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  tagText: {
    fontSize: 10,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  duration: {
    fontSize: 11,
    fontFamily: "DMSans_400Regular",
  },
  title: {
    fontSize: 15,
    fontFamily: "DMSans_500Medium",
    lineHeight: 21,
  },
  desc: {
    fontSize: 12,
    fontFamily: "DMSans_400Regular",
    lineHeight: 18,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 4,
  },
  play: {
    fontSize: 12,
    fontFamily: "DMSans_500Medium",
  },
});
