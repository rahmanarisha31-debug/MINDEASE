import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as Speech from "expo-speech";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Animated,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { WEB_GENERATORS } from "@/utils/webAudioAmbient";
import type { Session } from "./SessionCard";

interface Props {
  session: Session | null;
  visible: boolean;
  onClose: () => void;
  onComplete: () => void;
}

interface Segment {
  text: string;
  postPause: number;
}

const AMBIENT_TRACKS = [
  { id: "none",   label: "None",   icon: "slash" as const },
  { id: "rain",   label: "Rain",   icon: "cloud-rain" as const },
  { id: "ocean",  label: "Ocean",  icon: "wind" as const },
  { id: "forest", label: "Forest", icon: "feather" as const },
  { id: "bowls",  label: "Bowls",  icon: "disc" as const },
];

// ── Script parser ─────────────────────────────────────────────────────────────
function parseScript(script: string): Segment[] {
  const rawParts: string[] = [];
  const re = /[^.!?]+[.!?]+/g;
  let match: RegExpExecArray | null;
  let lastIndex = 0;
  while ((match = re.exec(script)) !== null) {
    rawParts.push(match[0].trim());
    lastIndex = match.index + match[0].length;
  }
  const tail = script.slice(lastIndex).trim();
  if (tail) rawParts.push(tail);
  if (rawParts.length === 0) return [{ text: script, postPause: 800 }];

  return rawParts.map((sentence) => {
    const countMatch = sentence.match(/\b(?:for|hold)\s+(\d+)\b/i);
    if (countMatch) {
      const n = Math.min(parseInt(countMatch[1], 10), 10);
      return { text: sentence, postPause: n * 950 };
    }
    const isInstruction = /\b(inhale|exhale|breathe|hold|repeat|pause|notice|feel|imagine|let go|release)\b/i.test(sentence);
    if (isInstruction) return { text: sentence, postPause: 1400 };
    const isReflective = /\b(drift|sink|warmth|settle|gently|slowly|deeper|aware|light|calm)\b/i.test(sentence);
    if (isReflective) return { text: sentence, postPause: 1100 };
    return { text: sentence, postPause: 800 };
  });
}

function safeStopSpeech() {
  try { Speech.stop(); } catch (_) {}
}

export function SessionPlayerModal({ session, visible, onClose, onComplete }: Props) {
  const colors = useColors();
  const [playing, setPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [ambientId, setAmbientId] = useState("rain");
  const [currentSegmentIdx, setCurrentSegmentIdx] = useState(-1);

  const progressAnim = useRef(new Animated.Value(0)).current;
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const onCompleteRef = useRef(onComplete);
  const durationRef = useRef((session?.durationMins ?? 5) * 60);

  // Web Audio ambient stop fn
  const stopAmbientRef = useRef<(() => void) | null>(null);

  // Narration chain
  const cancelChainRef = useRef(false);
  const pauseTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { onCompleteRef.current = onComplete; }, [onComplete]);
  useEffect(() => { durationRef.current = (session?.durationMins ?? 5) * 60; }, [session]);

  // ── Progress bar ─────────────────────────────────────────────────────────
  useEffect(() => {
    const d = durationRef.current;
    if (d <= 0) return;
    Animated.timing(progressAnim, {
      toValue: elapsed / d,
      duration: 800,
      useNativeDriver: false,
    }).start();
  }, [elapsed, progressAnim]);

  // ── Session completion ───────────────────────────────────────────────────
  useEffect(() => {
    const d = durationRef.current;
    if (elapsed >= d && elapsed > 0 && playing) {
      if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
      cancelChainRef.current = true;
      if (pauseTimeoutRef.current) { clearTimeout(pauseTimeoutRef.current); pauseTimeoutRef.current = null; }
      safeStopSpeech();
      stopAmbientRef.current?.();
      stopAmbientRef.current = null;
      setPlaying(false);
      setCurrentSegmentIdx(-1);
      onCompleteRef.current();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [elapsed]);

  // ── Ambient ──────────────────────────────────────────────────────────────
  const startAmbient = useCallback((id: string) => {
    stopAmbientRef.current?.();
    stopAmbientRef.current = null;
    if (id === "none") return;

    if (Platform.OS === "web") {
      const gen = WEB_GENERATORS[id];
      if (gen) {
        stopAmbientRef.current = gen(0.72);
      }
    }
    // Native: expo-av not available without bundled files; ambient is web-only for now
  }, []);

  const stopAmbient = useCallback(() => {
    stopAmbientRef.current?.();
    stopAmbientRef.current = null;
  }, []);

  // ── Cleanup on modal close ───────────────────────────────────────────────
  useEffect(() => {
    if (!visible) {
      if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
      cancelChainRef.current = true;
      if (pauseTimeoutRef.current) { clearTimeout(pauseTimeoutRef.current); pauseTimeoutRef.current = null; }
      safeStopSpeech();
      stopAmbient();
      setPlaying(false);
      setElapsed(0);
      setCurrentSegmentIdx(-1);
      progressAnim.setValue(0);
    }
  }, [visible, stopAmbient, progressAnim]);

  // ── Narration chain ──────────────────────────────────────────────────────
  const startChain = useCallback((segments: Segment[], index: number) => {
    if (cancelChainRef.current || index >= segments.length) {
      setCurrentSegmentIdx(-1);
      return;
    }
    const seg = segments[index];
    setCurrentSegmentIdx(index);
    const rate = Platform.OS === "ios" ? 0.42 : 0.78;

    try {
      Speech.speak(seg.text, {
        rate,
        pitch: 1.0,
        language: "en-US",
        onDone: () => {
          if (cancelChainRef.current) return;
          pauseTimeoutRef.current = setTimeout(() => {
            startChain(segments, index + 1);
          }, seg.postPause);
        },
        onError: () => {
          if (!cancelChainRef.current) {
            pauseTimeoutRef.current = setTimeout(() => startChain(segments, index + 1), 500);
          }
        },
      });
    } catch (_) {
      pauseTimeoutRef.current = setTimeout(() => startChain(segments, index + 1), 500);
    }
  }, []);

  // ── Play / Pause ─────────────────────────────────────────────────────────
  const togglePlay = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    if (playing) {
      if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
      cancelChainRef.current = true;
      if (pauseTimeoutRef.current) { clearTimeout(pauseTimeoutRef.current); pauseTimeoutRef.current = null; }
      safeStopSpeech();
      stopAmbient();
      setPlaying(false);
      setCurrentSegmentIdx(-1);
    } else {
      setPlaying(true);

      // Narration
      if (session?.script) {
        const segments = parseScript(session.script);
        cancelChainRef.current = false;
        startChain(segments, 0);
      }

      // Ambient
      startAmbient(ambientId);

      intervalRef.current = setInterval(() => {
        setElapsed((prev) => prev + 1);
      }, 1000);
    }
  }, [playing, session, ambientId, startAmbient, stopAmbient, startChain]);

  const skip = useCallback((delta: number) => {
    const d = durationRef.current;
    setElapsed((e) => Math.max(0, Math.min(d - 1, e + delta)));
  }, []);

  const switchAmbient = useCallback((trackId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setAmbientId(trackId);
    if (playing) {
      startAmbient(trackId);
    } else {
      stopAmbient();
    }
  }, [playing, startAmbient, stopAmbient]);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const barWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0%", "100%"],
  });

  if (!session) return null;

  const segments = parseScript(session.script);
  const currentSegment = currentSegmentIdx >= 0 ? segments[currentSegmentIdx] : null;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View
          style={[
            styles.modal,
            { backgroundColor: colors.card, borderRadius: 28, paddingBottom: Platform.OS === "web" ? 40 : 36 },
          ]}
        >
          {/* Close */}
          <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
            <Feather name="x" size={20} color={colors.mutedForeground} />
          </TouchableOpacity>

          {/* Tag */}
          <View style={[styles.tagPill, { backgroundColor: session.tagBg, borderRadius: 99 }]}>
            <Text style={[styles.tagText, { color: session.tagColor }]}>{session.tag}</Text>
          </View>

          {/* Title */}
          <Text style={[styles.title, { color: colors.foreground }]}>{session.title}</Text>

          {/* Progress */}
          <View style={styles.progressSection}>
            <View style={[styles.progressBg, { backgroundColor: colors.muted, borderRadius: 99 }]}>
              <Animated.View
                style={[styles.progressFill, { width: barWidth, backgroundColor: colors.primary, borderRadius: 99 }]}
              />
            </View>
            <View style={styles.timeRow}>
              <Text style={[styles.timeText, { color: colors.mutedForeground }]}>{formatTime(elapsed)}</Text>
              <Text style={[styles.timeText, { color: colors.mutedForeground }]}>{session.duration}</Text>
            </View>
          </View>

          {/* Transport */}
          <View style={styles.controls}>
            <TouchableOpacity onPress={() => skip(-15)} style={styles.skipBtn}>
              <Feather name="rotate-ccw" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.playBtn, { backgroundColor: colors.primary, borderRadius: 99 }]}
              onPress={togglePlay}
              activeOpacity={0.85}
            >
              <Feather name={playing ? "pause" : "play"} size={26} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => skip(15)} style={styles.skipBtn}>
              <Feather name="rotate-cw" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>

          {/* Live narration line */}
          <View style={[styles.narrationBadge, { backgroundColor: colors.primaryLight, borderRadius: 12 }]}>
            <Feather name="volume-2" size={12} color={colors.primary} />
            <Text style={[styles.narrationText, { color: colors.primaryDark }]} numberOfLines={2}>
              {playing && currentSegment
                ? currentSegment.text
                : playing
                ? "Pausing…"
                : "Voice narration ready"}
            </Text>
          </View>

          {/* Ambient picker */}
          <View style={styles.ambientSection}>
            <Text style={[styles.ambientLabel, { color: colors.mutedForeground }]}>
              Background sound
            </Text>
            <View style={styles.ambientRow}>
              {AMBIENT_TRACKS.map((track) => {
                const active = ambientId === track.id;
                return (
                  <TouchableOpacity
                    key={track.id}
                    style={[
                      styles.ambientPill,
                      {
                        backgroundColor: active ? colors.primary : colors.background,
                        borderColor: active ? colors.primary : colors.border,
                      },
                    ]}
                    onPress={() => switchAmbient(track.id)}
                    activeOpacity={0.78}
                  >
                    <Feather name={track.icon} size={13} color={active ? "#fff" : colors.mutedForeground} />
                    <Text style={[styles.ambientPillText, { color: active ? "#fff" : colors.foreground }]}>
                      {track.label}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* Script with sentence highlighting */}
          <View style={[styles.scriptCard, { backgroundColor: colors.background, borderRadius: 16 }]}>
            <Text style={[styles.scriptLabel, { color: colors.mutedForeground }]}>Script</Text>
            <Text style={styles.scriptContainer}>
              {segments.map((seg, i) => {
                const isActive = i === currentSegmentIdx;
                return (
                  <Text
                    key={i}
                    style={[
                      styles.scriptSegment,
                      {
                        color: isActive ? colors.primary : colors.foreground,
                        fontFamily: isActive ? "DMSans_500Medium" : "DMSans_400Regular",
                        opacity: playing && !isActive ? 0.4 : 1,
                      },
                    ]}
                  >
                    {seg.text}
                    {i < segments.length - 1 ? " " : ""}
                  </Text>
                );
              })}
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.50)",
    alignItems: "center",
    justifyContent: "flex-end",
  },
  modal: {
    width: "100%",
    maxWidth: 480,
    alignSelf: "center",
    padding: 24,
    gap: 14,
    alignItems: "center",
  },
  closeBtn: { alignSelf: "flex-end", marginBottom: -4 },
  tagPill: { paddingHorizontal: 12, paddingVertical: 4 },
  tagText: {
    fontSize: 11,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  title: {
    fontSize: 22,
    fontFamily: "DMSerifDisplay_400Regular",
    textAlign: "center",
    lineHeight: 28,
  },
  progressSection: { width: "100%", gap: 8 },
  progressBg: { width: "100%", height: 5, overflow: "hidden" },
  progressFill: { height: "100%" },
  timeRow: { flexDirection: "row", justifyContent: "space-between" },
  timeText: { fontSize: 11, fontFamily: "DMSans_400Regular" },
  controls: { flexDirection: "row", alignItems: "center", gap: 28, marginVertical: 2 },
  skipBtn: { padding: 6 },
  playBtn: { width: 60, height: 60, alignItems: "center", justifyContent: "center" },
  narrationBadge: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    width: "100%",
  },
  narrationText: { fontSize: 12, fontFamily: "DMSans_400Regular", flex: 1, lineHeight: 18 },
  ambientSection: { width: "100%", gap: 10 },
  ambientLabel: {
    fontSize: 10,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    textAlign: "center",
  },
  ambientRow: { flexDirection: "row", justifyContent: "center", gap: 8, flexWrap: "wrap" },
  ambientPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 99,
    borderWidth: 1.5,
  },
  ambientPillText: { fontSize: 13, fontFamily: "DMSans_400Regular" },
  scriptCard: { width: "100%", padding: 16, gap: 6 },
  scriptLabel: {
    fontSize: 10,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  scriptContainer: { fontSize: 13, lineHeight: 22 },
  scriptSegment: { fontSize: 13, lineHeight: 22 },
});
