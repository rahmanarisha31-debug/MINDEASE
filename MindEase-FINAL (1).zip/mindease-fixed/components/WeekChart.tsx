import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";
import type { MoodEntry } from "@/context/AppContext";

interface Props {
  moodHistory: MoodEntry[];
}

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function WeekChart({ moodHistory }: Props) {
  const colors = useColors();

  const weekData = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = d.toISOString().split("T")[0];
    const entry = moodHistory.find((m) => m.date === dateStr);
    const isToday = i === 6;
    return {
      day: DAYS[d.getDay()],
      value: entry?.value ?? 0,
      isToday,
    };
  });

  return (
    <View style={styles.container}>
      {weekData.map((d, i) => (
        <View key={i} style={styles.barWrap}>
          <View style={styles.barOuter}>
            <View
              style={[
                styles.bar,
                {
                  height: d.value ? `${(d.value / 5) * 100}%` : "4%",
                  backgroundColor: d.isToday
                    ? colors.primary
                    : d.value
                    ? colors.primaryLight
                    : colors.border,
                  borderRadius: 4,
                  opacity: d.value ? 1 : 0.5,
                },
              ]}
            />
          </View>
          <Text
            style={[
              styles.dayLabel,
              {
                color: d.isToday ? colors.primary : colors.mutedForeground,
                fontWeight: d.isToday ? "600" : "400",
              },
            ]}
          >
            {d.day}
          </Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 8,
    height: 90,
    marginTop: 8,
  },
  barWrap: {
    flex: 1,
    alignItems: "center",
    gap: 4,
    height: "100%",
    justifyContent: "flex-end",
  },
  barOuter: {
    flex: 1,
    width: "100%",
    justifyContent: "flex-end",
  },
  bar: {
    width: "100%",
  },
  dayLabel: {
    fontSize: 10,
    fontFamily: "DMSans_400Regular",
  },
});
