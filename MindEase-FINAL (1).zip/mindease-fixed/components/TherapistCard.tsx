import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/useColors";

export interface Therapist {
  name: string;
  specialty: string;
  rating: string;
  sessions: number;
  badge: string;
  color: string;
  initials: string;
}

interface Props {
  therapist: Therapist;
}

export function TherapistCard({ therapist }: Props) {
  const colors = useColors();
  const r = (colors as any).radius ?? 16;

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: r,
        },
      ]}
    >
      <View
        style={[
          styles.avatar,
          { backgroundColor: therapist.color + "22", borderRadius: 99 },
        ]}
      >
        <Text style={[styles.initials, { color: therapist.color }]}>
          {therapist.initials}
        </Text>
      </View>
      <View style={styles.info}>
        <View style={styles.nameRow}>
          <Text style={[styles.name, { color: colors.foreground }]}>
            {therapist.name}
          </Text>
          <View
            style={[
              styles.badge,
              { backgroundColor: colors.primaryLight, borderRadius: 99 },
            ]}
          >
            <Text style={[styles.badgeText, { color: colors.primaryDark }]}>
              {therapist.badge}
            </Text>
          </View>
        </View>
        <Text style={[styles.specialty, { color: colors.mutedForeground }]}>
          {therapist.specialty}
        </Text>
        <View style={styles.meta}>
          <Feather name="star" size={11} color={colors.amber} />
          <Text style={[styles.metaText, { color: colors.mutedForeground }]}>
            {therapist.rating} · {therapist.sessions} sessions
          </Text>
        </View>
      </View>
      <TouchableOpacity
        style={[
          styles.bookBtn,
          { backgroundColor: colors.primary, borderRadius: 10 },
        ]}
        onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)}
        activeOpacity={0.8}
      >
        <Text style={[styles.bookText, { color: colors.primaryForeground }]}>
          Book
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    gap: 12,
    borderWidth: 1,
  },
  avatar: {
    width: 50,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  initials: {
    fontSize: 16,
    fontFamily: "DMSans_500Medium",
  },
  info: {
    flex: 1,
    gap: 2,
  },
  nameRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flexWrap: "wrap",
  },
  name: {
    fontSize: 14,
    fontFamily: "DMSans_500Medium",
  },
  badge: {
    paddingHorizontal: 7,
    paddingVertical: 2,
  },
  badgeText: {
    fontSize: 10,
    fontFamily: "DMSans_500Medium",
  },
  specialty: {
    fontSize: 12,
    fontFamily: "DMSans_400Regular",
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 2,
  },
  metaText: {
    fontSize: 11,
    fontFamily: "DMSans_400Regular",
  },
  bookBtn: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  bookText: {
    fontSize: 13,
    fontFamily: "DMSans_500Medium",
  },
});
