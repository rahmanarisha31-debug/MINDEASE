import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { useColors } from "@/hooks/useColors";

interface Props {
  icon: keyof typeof Feather.glyphMap;
  iconBg: string;
  iconColor: string;
  title: string;
  body: string;
}

export function InsightCard({ icon, iconBg, iconColor, title, body }: Props) {
  const colors = useColors();
  const r = (colors as any).radius ?? 16;

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: r,
        },
      ]}
    >
      <View style={[styles.icon, { backgroundColor: iconBg, borderRadius: 10 }]}>
        <Feather name={icon} size={18} color={iconColor} />
      </View>
      <View style={styles.text}>
        <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.body, { color: colors.mutedForeground }]}>{body}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    gap: 14,
    padding: 16,
    borderWidth: 1,
  },
  icon: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  text: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    fontFamily: "DMSans_500Medium",
    marginBottom: 3,
  },
  body: {
    fontSize: 13,
    fontFamily: "DMSans_400Regular",
    lineHeight: 19,
  },
});
