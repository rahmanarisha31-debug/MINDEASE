import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useColors } from "@/hooks/useColors";

const MOODS = [
  { value: 1, label: "Rough", icon: "frown" as const },
  { value: 2, label: "Low", icon: "meh" as const },
  { value: 3, label: "Okay", icon: "smile" as const },
  { value: 4, label: "Good", icon: "smile" as const },
  { value: 5, label: "Great", icon: "sun" as const },
] as const;

interface Props {
  selected: number | null;
  onSelect: (value: number, label: string) => void;
}

export function MoodSelector({ selected, onSelect }: Props) {
  const colors = useColors();

  return (
    <View style={styles.row}>
      {MOODS.map((m) => {
        const isSelected = selected === m.value;
        return (
          <TouchableOpacity
            key={m.value}
            style={[
              styles.btn,
              {
                borderColor: isSelected ? colors.primary : colors.border,
                backgroundColor: isSelected ? colors.primaryLight : colors.card,
                borderRadius: (colors as any).radius ?? 12,
              },
            ]}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              onSelect(m.value, m.label);
            }}
            activeOpacity={0.7}
          >
            <Feather
              name={m.icon as "frown" | "meh" | "smile" | "sun"}
              size={22}
              color={isSelected ? colors.primaryDark : colors.mutedForeground}
            />
            <Text
              style={[
                styles.label,
                {
                  color: isSelected ? colors.primaryDark : colors.mutedForeground,
                  fontWeight: isSelected ? "600" : "400",
                },
              ]}
            >
              {m.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    gap: 8,
  },
  btn: {
    flex: 1,
    paddingVertical: 14,
    alignItems: "center",
    gap: 6,
    borderWidth: 1.5,
  },
  label: {
    fontSize: 11,
    fontFamily: "DMSans_400Regular",
  },
});
