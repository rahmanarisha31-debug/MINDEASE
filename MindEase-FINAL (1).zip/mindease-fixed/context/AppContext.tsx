import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export interface MoodEntry {
  date: string;
  value: number;
  label: string;
}

interface AppState {
  userName: string;
  userGoal: string;
  hasOnboarded: boolean;
  isLoaded: boolean;
  streak: number;
  sessionsCompleted: number;
  moodHistory: MoodEntry[];
  todayMood: MoodEntry | null;
  completeOnboarding: (name: string, goal: string) => void;
  updateProfile: (name: string, goal: string) => void;
  logMood: (value: number, label: string) => void;
  completeSession: () => void;
  clearMoodHistory: () => void;
  resetAll: () => void;
  avgMoodThisWeek: number;
}

const AppContext = createContext<AppState | null>(null);

const STORAGE_KEYS = {
  USER_NAME: "me_userName",
  USER_GOAL: "me_userGoal",
  HAS_ONBOARDED: "me_hasOnboarded",
  STREAK: "me_streak",
  SESSIONS: "me_sessions",
  MOOD_HISTORY: "me_moodHistory",
};

const today = () => new Date().toISOString().split("T")[0];

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [userName, setUserName] = useState("");
  const [userGoal, setUserGoal] = useState("");
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [streak, setStreak] = useState(3);
  const [sessionsCompleted, setSessionsCompleted] = useState(7);
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);

  useEffect(() => {
    (async () => {
      const [name, goal, onboarded, str, sess, moods] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.USER_NAME),
        AsyncStorage.getItem(STORAGE_KEYS.USER_GOAL),
        AsyncStorage.getItem(STORAGE_KEYS.HAS_ONBOARDED),
        AsyncStorage.getItem(STORAGE_KEYS.STREAK),
        AsyncStorage.getItem(STORAGE_KEYS.SESSIONS),
        AsyncStorage.getItem(STORAGE_KEYS.MOOD_HISTORY),
      ]);
      if (name) setUserName(name);
      if (goal) setUserGoal(goal);
      if (onboarded) setHasOnboarded(true);
      if (str) setStreak(parseInt(str));
      if (sess) setSessionsCompleted(parseInt(sess));
      if (moods) setMoodHistory(JSON.parse(moods));
      setIsLoaded(true);
    })();
  }, []);

  const completeOnboarding = useCallback(async (name: string, goal: string) => {
    setUserName(name);
    setUserGoal(goal);
    setHasOnboarded(true);
    await Promise.all([
      AsyncStorage.setItem(STORAGE_KEYS.USER_NAME, name),
      AsyncStorage.setItem(STORAGE_KEYS.USER_GOAL, goal),
      AsyncStorage.setItem(STORAGE_KEYS.HAS_ONBOARDED, "true"),
    ]);
  }, []);

  const logMood = useCallback(
    async (value: number, label: string) => {
      const entry: MoodEntry = { date: today(), value, label };
      const updated = [
        ...moodHistory.filter((m) => m.date !== today()),
        entry,
      ];
      setMoodHistory(updated);
      const newStreak = streak + 1;
      setStreak(newStreak);
      await Promise.all([
        AsyncStorage.setItem(STORAGE_KEYS.MOOD_HISTORY, JSON.stringify(updated)),
        AsyncStorage.setItem(STORAGE_KEYS.STREAK, String(newStreak)),
      ]);
    },
    [moodHistory, streak]
  );

  const updateProfile = useCallback(async (name: string, goal: string) => {
    setUserName(name);
    setUserGoal(goal);
    await Promise.all([
      AsyncStorage.setItem(STORAGE_KEYS.USER_NAME, name),
      AsyncStorage.setItem(STORAGE_KEYS.USER_GOAL, goal),
    ]);
  }, []);

  const completeSession = useCallback(async () => {
    const next = sessionsCompleted + 1;
    setSessionsCompleted(next);
    await AsyncStorage.setItem(STORAGE_KEYS.SESSIONS, String(next));
  }, [sessionsCompleted]);

  const clearMoodHistory = useCallback(async () => {
    setMoodHistory([]);
    await AsyncStorage.removeItem(STORAGE_KEYS.MOOD_HISTORY);
  }, []);

  const resetAll = useCallback(async () => {
    setUserName("");
    setUserGoal("");
    setHasOnboarded(false);
    setStreak(0);
    setSessionsCompleted(0);
    setMoodHistory([]);
    await Promise.all(Object.values(STORAGE_KEYS).map((k) => AsyncStorage.removeItem(k)));
  }, []);

  const todayMood = moodHistory.find((m) => m.date === today()) ?? null;

  const avgMoodThisWeek = (() => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recent = moodHistory.filter(
      (m) => new Date(m.date) >= sevenDaysAgo
    );
    if (!recent.length) return 3.2;
    return Math.round((recent.reduce((s, m) => s + m.value, 0) / recent.length) * 10) / 10;
  })();

  return (
    <AppContext.Provider
      value={{
        userName,
        userGoal,
        hasOnboarded,
        isLoaded,
        streak,
        sessionsCompleted,
        moodHistory,
        todayMood,
        completeOnboarding,
        updateProfile,
        logMood,
        completeSession,
        clearMoodHistory,
        resetAll,
        avgMoodThisWeek,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
