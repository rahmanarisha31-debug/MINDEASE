import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { SvgXml } from "react-native-svg";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const LOGO_SVG = `<svg width="56" height="56" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <rect width="100" height="100" rx="24" fill="#1D9E75"/>
  <ellipse cx="50" cy="60" rx="26" ry="30" fill="rgba(255,255,255,0.1)"/>
  <path d="M50 22 C46 22 43 25 43 29 C43 33 46 36 50 36 C54 36 57 33 57 29 C57 25 54 22 50 22 Z" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.4" stroke-linecap="round"/>
  <path d="M50 36 L50 41" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.4" stroke-linecap="round"/>
  <path d="M50 41 C43 42 37 47 35 55 C33 63 35 71 39 76 C43 80 47 82 50 82 C53 82 57 80 61 76 C65 71 67 63 65 55 C63 47 57 42 50 41 Z" fill="none" stroke="rgba(255,255,255,0.9)" stroke-width="1.4" stroke-linecap="round"/>
  <path d="M39 57 C41 55 45 54 47 56 C48 57 48 59 48 60" fill="none" stroke="rgba(255,255,255,0.75)" stroke-width="1.2" stroke-linecap="round"/>
  <path d="M61 57 C59 55 55 54 53 56 C52 57 52 59 52 60" fill="none" stroke="rgba(255,255,255,0.75)" stroke-width="1.2" stroke-linecap="round"/>
  <circle cx="50" cy="62" r="7" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="0.8"/>
  <circle cx="50" cy="62" r="13" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="0.6"/>
</svg>`;

const GOALS = [
  { id: "anxiety",    label: "Manage anxiety",    icon: "wind" as const },
  { id: "sleep",      label: "Sleep better",       icon: "moon" as const },
  { id: "stress",     label: "Reduce stress",      icon: "activity" as const },
  { id: "resilience", label: "Build resilience",   icon: "shield" as const },
  { id: "mood",       label: "Track my mood",      icon: "bar-chart-2" as const },
  { id: "mindful",    label: "Be more mindful",    icon: "eye" as const },
];

export default function OnboardingScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { completeOnboarding } = useApp();

  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [goal, setGoal] = useState("");
  const slideAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 40 : insets.bottom + 24;

  const animateToStep = (next: number) => {
    Animated.sequence([
      Animated.parallel([
        Animated.timing(slideAnim, { toValue: -24, duration: 160, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 0, duration: 160, useNativeDriver: true }),
      ]),
      Animated.timing(slideAnim, { toValue: 24, duration: 0, useNativeDriver: true }),
    ]).start(() => {
      setStep(next);
      Animated.parallel([
        Animated.timing(slideAnim, { toValue: 0, duration: 220, useNativeDriver: true }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 220, useNativeDriver: true }),
      ]).start();
    });
  };

  const handleNext = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    animateToStep(step + 1);
  };

  const handleFinish = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await completeOnboarding(name.trim(), goal);
    router.replace("/(tabs)");
  };

  const canAdvanceStep0 = name.trim().length >= 2;
  const canAdvanceStep1 = goal !== "";

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={[styles.inner, { paddingTop: topPad + 24, paddingBottom: bottomPad }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Logo */}
        <View style={styles.logoRow}>
          {Platform.OS === "web" ? (
            <View style={[styles.logoBox, { backgroundColor: colors.primary, borderRadius: 16 }]}>
              <Feather name="heart" size={26} color="#fff" />
            </View>
          ) : (
            <SvgXml xml={LOGO_SVG} width={56} height={56} />
          )}
          <View>
            <Text style={[styles.logoName, { color: colors.foreground }]}>
              Mind<Text style={{ color: colors.primary }}>Ease</Text>
            </Text>
            <Text style={[styles.logoTagline, { color: colors.mutedForeground }]}>
              Mental Wellness · AI · Therapy
            </Text>
          </View>
        </View>

        {/* Step dots */}
        <View style={styles.dotsRow}>
          {[0, 1, 2].map((i) => (
            <View
              key={i}
              style={[
                styles.dot,
                {
                  backgroundColor: i <= step ? colors.primary : colors.border,
                  width: i === step ? 24 : 8,
                },
              ]}
            />
          ))}
        </View>

        {/* Animated step content */}
        <Animated.View style={{ transform: [{ translateY: slideAnim }], opacity: fadeAnim }}>

          {/* STEP 0 — Name */}
          {step === 0 && (
            <View style={styles.stepContent}>
              <Text style={[styles.stepQ, { color: colors.foreground }]}>
                What's your name?
              </Text>
              <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>
                Let's make this personal from the start.
              </Text>
              <TextInput
                style={[
                  styles.input,
                  {
                    backgroundColor: colors.card,
                    borderColor: name.trim().length >= 2 ? colors.primary : colors.border,
                    color: colors.foreground,
                    borderRadius: 14,
                  },
                ]}
                value={name}
                onChangeText={setName}
                placeholder="Your first name"
                placeholderTextColor={colors.mutedForeground}
                autoFocus
                returnKeyType="next"
                onSubmitEditing={() => canAdvanceStep0 && handleNext()}
                autoCorrect={false}
              />
              <TouchableOpacity
                style={[
                  styles.primaryBtn,
                  { backgroundColor: canAdvanceStep0 ? colors.primary : colors.muted, borderRadius: 16 },
                ]}
                onPress={handleNext}
                disabled={!canAdvanceStep0}
                activeOpacity={0.82}
              >
                <Text style={[styles.primaryBtnText, { color: canAdvanceStep0 ? "#fff" : colors.mutedForeground }]}>
                  Continue
                </Text>
                <Feather name="arrow-right" size={18} color={canAdvanceStep0 ? "#fff" : colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          )}

          {/* STEP 1 — Goal */}
          {step === 1 && (
            <View style={styles.stepContent}>
              <Text style={[styles.stepQ, { color: colors.foreground }]}>
                What brings you here{name ? `, ${name}` : ""}?
              </Text>
              <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>
                Pick what resonates most right now.
              </Text>
              <View style={styles.goalGrid}>
                {GOALS.map((g) => {
                  const active = goal === g.id;
                  return (
                    <TouchableOpacity
                      key={g.id}
                      style={[
                        styles.goalBtn,
                        {
                          backgroundColor: active ? colors.primaryLight : colors.card,
                          borderColor: active ? colors.primary : colors.border,
                          borderRadius: 14,
                        },
                      ]}
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        setGoal(g.id);
                      }}
                      activeOpacity={0.8}
                    >
                      <Feather name={g.icon} size={18} color={active ? colors.primary : colors.mutedForeground} />
                      <Text
                        style={[
                          styles.goalLabel,
                          { color: active ? colors.primaryDark : colors.foreground },
                        ]}
                      >
                        {g.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
              <TouchableOpacity
                style={[
                  styles.primaryBtn,
                  { backgroundColor: canAdvanceStep1 ? colors.primary : colors.muted, borderRadius: 16 },
                ]}
                onPress={handleNext}
                disabled={!canAdvanceStep1}
                activeOpacity={0.82}
              >
                <Text style={[styles.primaryBtnText, { color: canAdvanceStep1 ? "#fff" : colors.mutedForeground }]}>
                  Continue
                </Text>
                <Feather name="arrow-right" size={18} color={canAdvanceStep1 ? "#fff" : colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          )}

          {/* STEP 2 — Ready */}
          {step === 2 && (
            <View style={styles.stepContent}>
              <View style={[styles.readyIcon, { backgroundColor: colors.primaryLight, borderRadius: 99 }]}>
                <Feather name="check" size={32} color={colors.primary} />
              </View>
              <Text style={[styles.stepQ, { color: colors.foreground, textAlign: "center" }]}>
                You're all set{name ? `, ${name}` : ""}
              </Text>
              <Text style={[styles.stepSub, { color: colors.mutedForeground, textAlign: "center" }]}>
                MindEase is a safe space to check in with yourself — no judgement, no pressure. Your data stays on your device.
              </Text>
              <View style={[styles.disclaimerBox, { backgroundColor: colors.muted, borderRadius: 12 }]}>
                <Feather name="info" size={13} color={colors.mutedForeground} />
                <Text style={[styles.disclaimerText, { color: colors.mutedForeground }]}>
                  MindEase is not a substitute for professional mental health treatment. If you're in crisis, please contact a qualified professional.
                </Text>
              </View>
              <TouchableOpacity
                style={[styles.primaryBtn, { backgroundColor: colors.primary, borderRadius: 16 }]}
                onPress={handleFinish}
                activeOpacity={0.82}
              >
                <Text style={[styles.primaryBtnText, { color: "#fff" }]}>Start my journey</Text>
                <Feather name="heart" size={18} color="#fff" />
              </TouchableOpacity>
            </View>
          )}
        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  inner: { paddingHorizontal: 28, gap: 28 },
  logoRow: { flexDirection: "row", alignItems: "center", gap: 14 },
  logoBox: { width: 56, height: 56, alignItems: "center", justifyContent: "center" },
  logoName: { fontSize: 26, fontFamily: "DMSerifDisplay_400Regular" },
  logoTagline: { fontSize: 11, fontFamily: "DMSans_400Regular", marginTop: 1 },
  dotsRow: { flexDirection: "row", gap: 6, alignItems: "center" },
  dot: { height: 4, borderRadius: 99 },
  stepContent: { gap: 20 },
  stepQ: { fontSize: 26, fontFamily: "DMSerifDisplay_400Regular", lineHeight: 33 },
  stepSub: { fontSize: 14, fontFamily: "DMSans_400Regular", lineHeight: 21, marginTop: -8 },
  input: {
    padding: 16, fontSize: 16, fontFamily: "DMSans_400Regular",
    borderWidth: 1.5,
  },
  primaryBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 10, padding: 17,
  },
  primaryBtnText: { fontSize: 16, fontFamily: "DMSans_500Medium" },
  goalGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  goalBtn: {
    flexDirection: "row", alignItems: "center", gap: 9,
    paddingHorizontal: 16, paddingVertical: 13,
    borderWidth: 1.5,
    minWidth: "45%", flex: 1,
  },
  goalLabel: { fontSize: 13, fontFamily: "DMSans_500Medium" },
  readyIcon: { width: 72, height: 72, alignItems: "center", justifyContent: "center", alignSelf: "center" },
  disclaimerBox: { flexDirection: "row", alignItems: "flex-start", gap: 10, padding: 14 },
  disclaimerText: { fontSize: 12, fontFamily: "DMSans_400Regular", lineHeight: 18, flex: 1 },
});
