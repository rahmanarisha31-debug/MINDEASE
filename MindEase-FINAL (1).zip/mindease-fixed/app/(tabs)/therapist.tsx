import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { TherapistCard, type Therapist } from "@/components/TherapistCard";
import { useColors } from "@/hooks/useColors";

const THERAPISTS: Therapist[] = [
  {
    name: "Dr. Priya Nair",
    specialty: "Anxiety & CBT",
    rating: "4.9",
    sessions: 312,
    badge: "Top Rated",
    color: "#7F77DD",
    initials: "PN",
  },
  {
    name: "Rahul Mehta",
    specialty: "Stress & Mindfulness",
    rating: "4.8",
    sessions: 198,
    badge: "Available",
    color: "#1D9E75",
    initials: "RM",
  },
  {
    name: "Anika Sharma",
    specialty: "Sleep & Mood",
    rating: "4.7",
    sessions: 245,
    badge: "Popular",
    color: "#EF9F27",
    initials: "AS",
  },
];

const CRISIS_RESOURCES = [
  { label: "iCall (India)", icon: "phone" as const },
  { label: "Vandrevala Foundation (24/7)", icon: "phone" as const },
  { label: "Crisis Text Line (US / CA / UK)", icon: "message-square" as const },
  { label: "Samaritans (UK & Ireland)", icon: "phone" as const },
];

export default function TherapistScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const r = (colors as any).radius ?? 16;
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPad + 20,
          paddingBottom: Platform.OS === "web" ? 100 : insets.bottom + 100,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.headerBlock}>
        <Text style={[styles.title, { color: colors.foreground }]}>Therapist</Text>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>
          Licensed professionals, ready when you need them.
        </Text>
      </View>

      <View
        style={[
          styles.introBanner,
          {
            backgroundColor: colors.primaryLight,
            borderColor: colors.primary,
            borderRadius: r,
          },
        ]}
      >
        <Text style={[styles.introTitle, { color: colors.primaryDark }]}>
          Human support, on your terms
        </Text>
        <Text style={[styles.introBody, { color: colors.primaryDark }]}>
          Book a 20-minute async text session with a licensed therapist. They'll respond within 24 hours — no scheduling pressure.
        </Text>
      </View>

      <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
        Available therapists
      </Text>

      {THERAPISTS.map((t) => (
        <TherapistCard key={t.name} therapist={t} />
      ))}

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: r }]}>
        <Text style={[styles.cardTitle, { color: colors.mutedForeground }]}>Crisis resources</Text>
        {CRISIS_RESOURCES.map((res, i) => (
          <View key={i} style={styles.crisisRow}>
            <View style={[styles.crisisIcon, { backgroundColor: colors.destructiveLight, borderRadius: 8 }]}>
              <Feather name={res.icon} size={14} color={colors.destructive} />
            </View>
            <Text style={[styles.crisisLabel, { color: colors.foreground }]}>{res.label}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  headerBlock: { gap: 4 },
  title: { fontSize: 26, fontFamily: "DMSerifDisplay_400Regular" },
  sub: { fontSize: 13, fontFamily: "DMSans_400Regular" },
  introBanner: { padding: 16, borderWidth: 1, gap: 6 },
  introTitle: { fontSize: 15, fontFamily: "DMSans_500Medium" },
  introBody: { fontSize: 13, fontFamily: "DMSans_400Regular", lineHeight: 20 },
  sectionLabel: {
    fontSize: 11,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.6,
    marginBottom: -4,
  },
  card: { padding: 18, borderWidth: 1, gap: 12 },
  cardTitle: {
    fontSize: 11,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.6,
  },
  crisisRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  crisisIcon: { width: 32, height: 32, alignItems: "center", justifyContent: "center" },
  crisisText: { flex: 1 },
  crisisLabel: { fontSize: 13, fontFamily: "DMSans_400Regular" },
  crisisContact: { fontSize: 13, fontFamily: "DMSans_500Medium" },
});
