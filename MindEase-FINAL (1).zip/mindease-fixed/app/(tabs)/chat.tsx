import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  FlatList,
  Linking,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";

interface Message {
  id: string;
  role: "ai" | "user";
  text: string;
  streaming?: boolean;
}

const API_BASE = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}/api`
  : "/api";

const DISTRESS_KEYWORDS = [
  "suicide", "kill myself", "end my life", "self-harm", "hurt myself",
  "no reason to live", "want to die", "can't go on", "can not go on",
  "don't want to be here", "not worth living", "give up on life",
  "cutting myself", "overdose", "harm myself",
];

function checkDistress(text: string): boolean {
  const lower = text.toLowerCase();
  return DISTRESS_KEYWORDS.some((kw) => lower.includes(kw));
}

function makeId() {
  return Date.now().toString() + Math.random().toString(36).substring(2, 7);
}

function MessageBubble({ msg, colors }: { msg: Message; colors: ReturnType<typeof useColors> }) {
  const isUser = msg.role === "user";
  return (
    <View style={[styles.msgRow, isUser && styles.msgRowUser]}>
      {!isUser && (
        <View style={[styles.msgAvatar, { backgroundColor: colors.primaryLight, borderRadius: 99 }]}>
          <Feather name="cpu" size={12} color={colors.primaryDark} />
        </View>
      )}
      <View
        style={[
          styles.bubble,
          {
            backgroundColor: isUser ? colors.primary : colors.card,
            borderColor: isUser ? "transparent" : colors.border,
            borderRadius: 16,
          },
        ]}
      >
        <Text style={[styles.bubbleText, { color: isUser ? "#fff" : colors.foreground }]}>
          {msg.text}
          {msg.streaming && (
            <Text style={{ color: isUser ? "rgba(255,255,255,0.6)" : colors.mutedForeground }}>▋</Text>
          )}
        </Text>
      </View>
      {isUser && (
        <View style={[styles.msgAvatar, { backgroundColor: colors.accentLight, borderRadius: 99 }]}>
          <Feather name="user" size={12} color={colors.accentDark} />
        </View>
      )}
    </View>
  );
}

function DistressBanner({ colors, onDismiss }: { colors: ReturnType<typeof useColors>; onDismiss: () => void }) {
  return (
    <View style={[styles.distressBanner, { backgroundColor: colors.destructiveLight, borderColor: colors.destructive, borderRadius: 14 }]}>
      <View style={styles.distressHeader}>
        <Feather name="heart" size={15} color={colors.destructive} />
        <Text style={[styles.distressTitle, { color: colors.destructive }]}>
          We're here with you
        </Text>
        <TouchableOpacity onPress={onDismiss} style={styles.dismissBtn}>
          <Feather name="x" size={14} color={colors.destructive} />
        </TouchableOpacity>
      </View>
      <Text style={[styles.distressBody, { color: colors.destructive }]}>
        It sounds like you're going through something really hard. You don't have to face this alone.
      </Text>
      <View style={styles.distressActions}>
        <TouchableOpacity
          style={[styles.distressBtn, { backgroundColor: colors.destructive }]}
          onPress={() => router.push("/(tabs)/therapist")}
        >
          <Text style={styles.distressBtnText}>Talk to a therapist</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.distressBtnOutline, { borderColor: colors.destructive }]}
          onPress={() => Linking.openURL("tel:9152987821")}
        >
          <Text style={[styles.distressBtnOutlineText, { color: colors.destructive }]}>Call iCall</Text>
        </TouchableOpacity>
      </View>
      <Text style={[styles.distressCrisis, { color: colors.destructive }]}>
        Crisis lines: iCall 9152987821 · Vandrevala 1860-2662-345 (24/7)
      </Text>
    </View>
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "intro",
      role: "ai",
      text: "Hi there. This is a safe space — there's no judgement here. What's on your mind today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [convId, setConvId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showDistress, setShowDistress] = useState(false);
  const flatRef = useRef<FlatList>(null);

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/anthropic/conversations`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: "Check-in " + new Date().toLocaleDateString() }),
        });
        if (!res.ok) throw new Error("Failed to create conversation");
        const data = await res.json();
        setConvId(data.id);
      } catch (e) {
        setError("Couldn't connect to the AI. Please try again later.");
      }
    })();
  }, []);

  const scrollToEnd = useCallback(() => {
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 80);
  }, []);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || busy || !convId) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setInput("");
    setError(null);

    // Distress detection
    if (checkDistress(text)) {
      setShowDistress(true);
    }

    const userMsg: Message = { id: makeId(), role: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    scrollToEnd();

    setBusy(true);

    const aiId = makeId();
    setMessages((prev) => [...prev, { id: aiId, role: "ai", text: "", streaming: true }]);
    scrollToEnd();

    try {
      const res = await fetch(`${API_BASE}/anthropic/conversations/${convId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
      });

      if (!res.ok || !res.body) throw new Error("Stream unavailable");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const payload = JSON.parse(line.slice(6));
            if (payload.done) break;
            if (payload.error) throw new Error(payload.error);
            if (payload.content) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === aiId ? { ...m, text: m.text + payload.content } : m
                )
              );
              scrollToEnd();
            }
          } catch (_) {}
        }
      }

      setMessages((prev) =>
        prev.map((m) => (m.id === aiId ? { ...m, streaming: false } : m))
      );
    } catch (e) {
      setMessages((prev) => prev.filter((m) => m.id !== aiId));
      setError("Something went wrong. Please try again.");
    } finally {
      setBusy(false);
      scrollToEnd();
    }
  }, [input, busy, convId, scrollToEnd]);

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior="padding"
      keyboardVerticalOffset={0}
    >
      <View
        style={[
          styles.header,
          {
            paddingTop: Platform.OS === "web" ? 67 : insets.top + 16,
            backgroundColor: colors.background,
          },
        ]}
      >
        <Text style={[styles.title, { color: colors.foreground }]}>AI Check-in</Text>
        <View style={styles.headerRow}>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            A safe space to talk — any time.
          </Text>
          <View
            style={[
              styles.liveTag,
              { backgroundColor: convId ? colors.primaryLight : colors.muted },
            ]}
          >
            <View
              style={[
                styles.liveDot,
                { backgroundColor: convId ? colors.primary : colors.mutedForeground },
              ]}
            />
            <Text
              style={[
                styles.liveText,
                { color: convId ? colors.primaryDark : colors.mutedForeground },
              ]}
            >
              {convId ? "Claude AI" : "Connecting…"}
            </Text>
          </View>
        </View>
      </View>

      <FlatList
        ref={flatRef}
        data={messages}
        keyExtractor={(m) => m.id}
        renderItem={({ item }) => <MessageBubble msg={item} colors={colors} />}
        contentContainerStyle={styles.messageList}
        keyboardDismissMode="interactive"
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        onContentSizeChange={scrollToEnd}
        ListFooterComponent={
          <>
            {showDistress && (
              <DistressBanner colors={colors} onDismiss={() => setShowDistress(false)} />
            )}
            {error ? (
              <View style={[styles.errorBanner, { backgroundColor: colors.destructiveLight, borderRadius: 10 }]}>
                <Feather name="alert-circle" size={13} color={colors.destructive} />
                <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
              </View>
            ) : null}
          </>
        }
      />

      <View
        style={[
          styles.inputBar,
          {
            backgroundColor: colors.background,
            borderTopColor: colors.border,
            paddingBottom: bottomPad + 8,
          },
        ]}
      >
        <TextInput
          style={[
            styles.input,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
              borderRadius: 12,
              color: colors.foreground,
              fontFamily: "DMSans_400Regular",
            },
          ]}
          value={input}
          onChangeText={setInput}
          placeholder="Share what's on your mind…"
          placeholderTextColor={colors.mutedForeground}
          multiline
          maxLength={500}
          returnKeyType="send"
          blurOnSubmit
          editable={!busy}
        />
        <TouchableOpacity
          style={[
            styles.sendBtn,
            {
              backgroundColor: input.trim() && !busy && convId ? colors.primary : colors.muted,
              borderRadius: 12,
            },
          ]}
          onPress={send}
          disabled={!input.trim() || busy || !convId}
          activeOpacity={0.8}
        >
          {busy ? (
            <Feather name="loader" size={18} color={colors.mutedForeground} />
          ) : (
            <Feather name="send" size={18} color={input.trim() && convId ? "#fff" : colors.mutedForeground} />
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16 },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 3,
  },
  title: { fontSize: 26, fontFamily: "DMSerifDisplay_400Regular" },
  subtitle: { fontSize: 13, fontFamily: "DMSans_400Regular" },
  liveTag: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 99,
  },
  liveDot: { width: 6, height: 6, borderRadius: 99 },
  liveText: { fontSize: 11, fontFamily: "DMSans_500Medium" },
  messageList: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 16, gap: 12 },
  msgRow: { flexDirection: "row", alignItems: "flex-end", gap: 8 },
  msgRowUser: { justifyContent: "flex-end" },
  msgAvatar: {
    width: 28, height: 28,
    alignItems: "center", justifyContent: "center", flexShrink: 0,
  },
  bubble: {
    maxWidth: "75%",
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
  },
  bubbleText: { fontSize: 14, lineHeight: 21, fontFamily: "DMSans_400Regular" },
  distressBanner: {
    borderWidth: 1,
    padding: 16,
    marginTop: 8,
    marginHorizontal: 4,
    gap: 10,
  },
  distressHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  distressTitle: { fontSize: 14, fontFamily: "DMSans_500Medium", flex: 1 },
  dismissBtn: { padding: 2 },
  distressBody: { fontSize: 13, fontFamily: "DMSans_400Regular", lineHeight: 19 },
  distressActions: { flexDirection: "row", gap: 10 },
  distressBtn: {
    flex: 1, paddingVertical: 10, borderRadius: 10,
    alignItems: "center", justifyContent: "center",
  },
  distressBtnText: { color: "#fff", fontSize: 13, fontFamily: "DMSans_500Medium" },
  distressBtnOutline: {
    flex: 1, paddingVertical: 10, borderRadius: 10,
    borderWidth: 1.5, alignItems: "center", justifyContent: "center",
  },
  distressBtnOutlineText: { fontSize: 13, fontFamily: "DMSans_500Medium" },
  distressCrisis: { fontSize: 11, fontFamily: "DMSans_400Regular", lineHeight: 16 },
  errorBanner: {
    flexDirection: "row", alignItems: "center", gap: 8,
    padding: 12, marginTop: 8, marginHorizontal: 4,
  },
  errorText: { fontSize: 13, fontFamily: "DMSans_400Regular", flex: 1 },
  inputBar: {
    flexDirection: "row", gap: 10,
    paddingHorizontal: 16, paddingTop: 10, borderTopWidth: 1,
  },
  input: {
    flex: 1, paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 14, borderWidth: 1, maxHeight: 100,
  },
  sendBtn: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
});
