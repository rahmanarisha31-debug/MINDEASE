import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { WeekChart } from "@/components/WeekChart";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const MOOD_META: Record<number, { label: string; color: string; bg: string }> = {
  1: { label: "Rough",  color: "#E24B4A", bg: "#FCEBEB" },
  2: { label: "Low",    color: "#EF9F27", bg: "#FAEEDA" },
  3: { label: "Okay",   color: "#7F77DD", bg: "#EEEDFE" },
  4: { label: "Good",   color: "#1D9E75", bg: "#E1F5EE" },
  5: { label: "Great",  color: "#085041", bg: "#E1F5EE" },
};

const TIPS = [
  {
    icon: "moon" as const,
    color: "#0C447C",
    bg: "#E6F1FB",
    headline: "Consistent sleep beats more sleep",
    body: "Going to bed at the same time each night has a stronger effect on mood than sleeping longer.",
  },
  {
    icon: "zap" as const,
    color: "#EF9F27",
    bg: "#FAEEDA",
    headline: "5 minutes counts",
    body: "Short daily sessions build more resilience over time than occasional long ones.",
  },
  {
    icon: "heart" as const,
    color: "#E24B4A",
    bg: "#FCEBEB",
    headline: "Bad days are part of the pattern",
    body: "Noticing a low mood is already a step toward managing it. You don't need to feel good every day.",
  },
  {
    icon: "wind" as const,
    color: "#1D9E75",
    bg: "#E1F5EE",
    headline: "Breathing resets the nervous system",
    body: "Even two slow exhales activate the vagus nerve and reduce physiological stress within 30 seconds.",
  },
];

export default function InsightsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { moodHistory, avgMoodThisWeek } = useApp();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const recentMoods = moodHistory.filter((m) => new Date(m.date) >= sevenDaysAgo);

  const allDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return moodHistory.find((m) => m.date === d.toISOString().split("T")[0]);
  });
  const validDays = allDays.filter(Boolean);

  const bestDay = validDays.length
    ? validDays.reduce<typeof validDays[0]>((b, d) => (!b || d!.value > b!.value ? d : b), undefined)
    : null;
  const bestDayLabel = bestDay
    ? new Date(bestDay.date + "T00:00:00").toLocaleDateString("en", { weekday: "short" })
    : null;

  const trend =
    validDays.length >= 2
      ? validDays[validDays.length - 1]!.value >= validDays[0]!.value
        ? "up"
        : "down"
      : null;

  // Mood counts for breakdown
  const moodCounts: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  recentMoods.forEach((m) => { moodCounts[m.value] = (moodCounts[m.value] ?? 0) + 1; });
  const maxCount = Math.max(...Object.values(moodCounts), 1);
  const totalLogged = recentMoods.length;

  // Summary sentence
  const avgNum = typeof avgMoodThisWeek === "number" ? avgMoodThisWeek : parseFloat(String(avgMoodThisWeek));
  const summaryText =
    totalLogged === 0
      ? "Start logging your mood daily to see patterns here."
      : avgNum >= 4
      ? `You've been feeling mostly good this week. Keep it up.`
      : avgNum >= 3
      ? `Your mood has been steady this week. Small steps help.`
      : `This week has been tough. Be gentle with yourself.`;

  const avgMood = MOOD_META[Math.round(avgNum)] ?? MOOD_META[3];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: topPad + 20,
          paddingBottom: Platform.OS === "web" ? 100 : insets.bottom + 100,
        },
      ]}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.title, { color: colors.foreground }]}>Insights</Text>

      {/* ── SUMMARY CARD ── */}
      <View style={[styles.summaryCard, { backgroundColor: avgMood.bg, borderRadius: 20 }]}>
        <Text style={[styles.summaryText, { color: avgMood.color }]}>{summaryText}</Text>
        <View style={styles.summaryStats}>
          <View style={styles.summaryStat}>
            <Text style={[styles.summaryStatNum, { color: avgMood.color }]}>{totalLogged}/7</Text>
            <Text style={[styles.summaryStatLbl, { color: avgMood.color, opacity: 0.7 }]}>days logged</Text>
          </View>
          {bestDayLabel && (
            <View style={styles.summaryStat}>
              <Text style={[styles.summaryStatNum, { color: avgMood.color }]}>{bestDayLabel}</Text>
              <Text style={[styles.summaryStatLbl, { color: avgMood.color, opacity: 0.7 }]}>best day</Text>
            </View>
          )}
          {trend && (
            <View style={styles.summaryStat}>
              <View style={styles.trendRow}>
                <Feather
                  name={trend === "up" ? "trending-up" : "trending-down"}
                  size={18}
                  color={avgMood.color}
                />
              </View>
              <Text style={[styles.summaryStatLbl, { color: avgMood.color, opacity: 0.7 }]}>
                {trend === "up" ? "improving" : "dipping"}
              </Text>
            </View>
          )}
        </View>
      </View>

      {/* ── WEEK CHART ── */}
      <View style={[styles.card, { backgroundColor: colors.card, borderRadius: 20 }]}>
        <Text style={[styles.cardTitle, { color: colors.mutedForeground }]}>This week</Text>
        <WeekChart moodHistory={moodHistory} />
        <View style={styles.weekLegend}>
          {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((day, i) => {
            const entry = allDays[i];
            const meta = entry ? MOOD_META[entry.value] : null;
            return (
              <View key={day} style={styles.legendItem}>
                <View
                  style={[
                    styles.legendDot,
                    { backgroundColor: meta ? meta.color : colors.muted },
                  ]}
                />
                <Text style={[styles.legendDay, { color: colors.mutedForeground }]}>{day}</Text>
                {meta && (
                  <Text style={[styles.legendMood, { color: meta.color }]}>{meta.label}</Text>
                )}
              </View>
            );
          })}
        </View>
      </View>

      {/* ── MOOD BREAKDOWN ── */}
      <View style={[styles.card, { backgroundColor: colors.card, borderRadius: 20 }]}>
        <Text style={[styles.cardTitle, { color: colors.mutedForeground }]}>Mood breakdown</Text>
        {[5, 4, 3, 2, 1].map((val) => {
          const meta = MOOD_META[val];
          const count = moodCounts[val];
          const pct = maxCount > 0 ? (count / maxCount) * 100 : 0;
          return (
            <View key={val} style={styles.barRow}>
              <View style={[styles.barChip, { backgroundColor: meta.bg }]}>
                <Text style={[styles.barChipText, { color: meta.color }]}>{meta.label}</Text>
              </View>
              <View style={[styles.barTrack, { backgroundColor: colors.muted, borderRadius: 99 }]}>
                <View
                  style={[
                    styles.barFill,
                    {
                      width: `${pct}%` as `${number}%`,
                      backgroundColor: meta.color,
                      borderRadius: 99,
                      minWidth: count > 0 ? 10 : 0,
                    },
                  ]}
                />
              </View>
              <Text style={[styles.barDays, { color: count > 0 ? meta.color : colors.mutedForeground }]}>
                {count > 0 ? `${count}d` : "—"}
              </Text>
            </View>
          );
        })}
      </View>

      {/* ── WELLNESS TIPS ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Did you know</Text>
      {TIPS.map((tip, i) => (
        <View key={i} style={[styles.tipCard, { backgroundColor: colors.card, borderRadius: 16 }]}>
          <View style={[styles.tipIcon, { backgroundColor: tip.bg, borderRadius: 10 }]}>
            <Feather name={tip.icon} size={16} color={tip.color} />
          </View>
          <View style={styles.tipBody}>
            <Text style={[styles.tipHeadline, { color: colors.foreground }]}>{tip.headline}</Text>
            <Text style={[styles.tipText, { color: colors.mutedForeground }]}>{tip.body}</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  title: { fontSize: 28, fontFamily: "DMSerifDisplay_400Regular" },

  summaryCard: { padding: 20, gap: 14 },
  summaryText: { fontSize: 15, fontFamily: "DMSans_500Medium", lineHeight: 22 },
  summaryStats: { flexDirection: "row", gap: 24 },
  summaryStat: { gap: 3 },
  summaryStatNum: { fontSize: 18, fontFamily: "DMSerifDisplay_400Regular", lineHeight: 22 },
  summaryStatLbl: { fontSize: 11, fontFamily: "DMSans_400Regular" },
  trendRow: { height: 22, justifyContent: "center" },

  card: { padding: 18, gap: 14 },
  cardTitle: {
    fontSize: 11,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.6,
  },

  weekLegend: { flexDirection: "row", justifyContent: "space-between" },
  legendItem: { alignItems: "center", gap: 4, flex: 1 },
  legendDot: { width: 6, height: 6, borderRadius: 99 },
  legendDay: { fontSize: 9, fontFamily: "DMSans_400Regular" },
  legendMood: { fontSize: 8, fontFamily: "DMSans_500Medium" },

  barRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  barChip: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99, width: 56, alignItems: "center" },
  barChipText: { fontSize: 11, fontFamily: "DMSans_500Medium" },
  barTrack: { flex: 1, height: 9, overflow: "hidden" },
  barFill: { height: "100%" },
  barDays: { fontSize: 11, fontFamily: "DMSans_500Medium", width: 22, textAlign: "right" },

  sectionLabel: {
    fontSize: 11,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.6,
    marginBottom: -4,
  },
  tipCard: { flexDirection: "row", alignItems: "flex-start", padding: 14, gap: 12 },
  tipIcon: { width: 36, height: 36, alignItems: "center", justifyContent: "center", marginTop: 1 },
  tipBody: { flex: 1, gap: 4 },
  tipHeadline: { fontSize: 13, fontFamily: "DMSans_500Medium", lineHeight: 18 },
  tipText: { fontSize: 12, fontFamily: "DMSans_400Regular", lineHeight: 18 },
});
