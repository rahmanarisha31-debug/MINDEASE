import React, { useState } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { SessionCard, type Session } from "@/components/SessionCard";
import { SessionPlayerModal } from "@/components/SessionPlayerModal";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const ALL_SESSIONS: Session[] = [
  {
    id: "1", tag: "Anxiety", title: "4-7-8 Breathing",
    duration: "5 min", durationMins: 5,
    description: "A simple breathing pattern that calms the nervous system within minutes.",
    script: "Find a comfortable position, close your eyes. Inhale through your nose for 4 counts. Hold for 7. Exhale completely through your mouth for 8 counts. Repeat 4 times. Notice your body softening with each cycle.",
    tagColor: "#3C3489", tagBg: "#EEEDFE",
  },
  {
    id: "2", tag: "Stress", title: "Body Scan Release",
    duration: "10 min", durationMins: 10,
    description: "A progressive relaxation technique that releases tension held in the body.",
    script: "Start by noticing your breath. Bring awareness to your feet and toes, releasing any tension. Slowly move up through your legs, abdomen, chest, and shoulders. Let each area soften as you breathe out.",
    tagColor: "#633806", tagBg: "#FAEEDA",
  },
  {
    id: "3", tag: "Sleep", title: "Sleep Drift",
    duration: "15 min", durationMins: 15,
    description: "A gentle guided visualization to ease your mind into restful sleep.",
    script: "Let your body sink into the surface below you. Imagine a warm light moving through you from head to toe. With each breath, you drift a little deeper into rest. There is nothing to do. Nowhere to be. Only this moment.",
    tagColor: "#0C447C", tagBg: "#E6F1FB",
  },
  {
    id: "4", tag: "Mood", title: "Gratitude Flow",
    duration: "7 min", durationMins: 7,
    description: "A CBT-based exercise to shift perspective and lift mood through reflection.",
    script: "Bring to mind three things that went well today. They don't need to be big. For each one, pause and notice how it felt. Let that warmth settle in your chest. You have more good in your life than you often notice.",
    tagColor: "#085041", tagBg: "#E1F5EE",
  },
  {
    id: "5", tag: "Anxiety", title: "5-4-3-2-1 Grounding",
    duration: "5 min", durationMins: 5,
    description: "A grounding technique that anchors you in the present moment.",
    script: "Name 5 things you can see. 4 things you can physically feel. 3 things you can hear. 2 things you can smell. 1 thing you can taste. You are here. You are safe. Take one more slow breath.",
    tagColor: "#3C3489", tagBg: "#EEEDFE",
  },
  {
    id: "6", tag: "Breathing", title: "Box Breathing",
    duration: "8 min", durationMins: 8,
    description: "Used by elite athletes and special forces to reduce stress instantly.",
    script: "Inhale for 4 counts. Hold for 4. Exhale for 4. Hold for 4. Repeat this box pattern, maintaining a steady rhythm. Your nervous system will begin to calm. Continue for at least 4 full cycles.",
    tagColor: "#712B13", tagBg: "#FAECE7",
  },
  {
    id: "7", tag: "Mood", title: "Loving-Kindness",
    duration: "8 min", durationMins: 8,
    description: "Cultivate compassion for yourself and others — a proven mood lifter.",
    script: "Place one hand on your heart. Feel its warmth. Silently repeat: May I be happy. May I be healthy. May I be at peace. Now bring to mind someone you love. Extend the same wish to them. Then to all beings everywhere.",
    tagColor: "#085041", tagBg: "#E1F5EE",
  },
  {
    id: "8", tag: "Anxiety", title: "Anxious Thought Audit",
    duration: "6 min", durationMins: 6,
    description: "Separate facts from fears using a CBT thought record.",
    script: "Take the anxious thought on your mind. Rate how true it feels from 0 to 100. List the facts that support it. Now list the facts against it. Write a more balanced version. Re-rate the original thought. Often just examining a thought changes its power over us.",
    tagColor: "#3C3489", tagBg: "#EEEDFE",
  },
  {
    id: "9", tag: "Stress", title: "Mindful Breathing",
    duration: "3 min", durationMins: 3,
    description: "The simplest practice — just follow your breath as it is.",
    script: "You don't need to change anything. Just notice your breath right now. Is it shallow or deep? Fast or slow? Feel the air at your nostrils. The rise of your chest. The pause at the top. When your mind wanders, gently return. That return is the practice.",
    tagColor: "#633806", tagBg: "#FAEEDA",
  },
  {
    id: "10", tag: "Sleep", title: "Progressive Muscle Relaxation",
    duration: "12 min", durationMins: 12,
    description: "Release physical tension stored in your muscles systematically.",
    script: "Start with your hands. Clench them tightly. Hold 5 seconds. Now release completely. Notice the contrast. Move to your forearms, then upper arms, shoulders, face, chest, abdomen, legs, feet. With each release, your body learns what true relaxation feels like.",
    tagColor: "#0C447C", tagBg: "#E6F1FB",
  },
  {
    id: "11", tag: "Mood", title: "Cognitive Reframing",
    duration: "6 min", durationMins: 6,
    description: "Challenge unhelpful thought patterns with CBT questioning.",
    script: "Think of a thought that has been bothering you. Hold it gently in mind. Ask: is this a fact, or an interpretation? What evidence supports it? What contradicts it? What would you say to a close friend who had this thought? Offer yourself that same kindness.",
    tagColor: "#085041", tagBg: "#E1F5EE",
  },
  {
    id: "12", tag: "Breathing", title: "Physiological Sigh",
    duration: "3 min", durationMins: 3,
    description: "The fastest known way to reduce stress — used by neuroscientists.",
    script: "Take a normal inhale through your nose. At the top, take a second short sniff to fully inflate your lungs. Now exhale slowly and completely through your mouth. Repeat this twice more. This double inhale followed by a long exhale activates your parasympathetic nervous system almost instantly.",
    tagColor: "#712B13", tagBg: "#FAECE7",
  },
];

const FILTER_TAGS = ["All", "Anxiety", "Stress", "Sleep", "Mood", "Breathing"];

export default function SessionsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { completeSession } = useApp();
  const [activeSession, setActiveSession] = useState<Session | null>(null);
  const [playerVisible, setPlayerVisible] = useState(false);
  const [activeFilter, setActiveFilter] = useState("All");

  const r = (colors as any).radius ?? 16;
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const filtered = activeFilter === "All"
    ? ALL_SESSIONS
    : ALL_SESSIONS.filter((s) => s.tag === activeFilter);

  const openSession = (session: Session) => {
    setActiveSession(session);
    setPlayerVisible(true);
  };

  const handleComplete = () => {
    completeSession();
    setPlayerVisible(false);
  };

  return (
    <>
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: topPad + 20,
            paddingBottom: Platform.OS === "web" ? 100 : insets.bottom + 100,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerBlock}>
          <Text style={[styles.title, { color: colors.foreground }]}>Sessions</Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            Short, guided exercises — pick what fits your mood.
          </Text>
        </View>

        {/* Filter pills */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {FILTER_TAGS.map((tag) => {
            const active = tag === activeFilter;
            return (
              <TouchableOpacity
                key={tag}
                style={[
                  styles.filterPill,
                  {
                    backgroundColor: active ? colors.primary : colors.card,
                    borderColor: active ? colors.primary : colors.border,
                    borderRadius: 99,
                  },
                ]}
                onPress={() => setActiveFilter(tag)}
                activeOpacity={0.78}
              >
                <Text
                  style={[
                    styles.filterText,
                    { color: active ? "#fff" : colors.mutedForeground },
                  ]}
                >
                  {tag}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        <Text style={[styles.countLabel, { color: colors.mutedForeground }]}>
          {filtered.length} session{filtered.length !== 1 ? "s" : ""}
        </Text>

        <View style={styles.grid}>
          {filtered.map((s) => (
            <SessionCard key={s.id} session={s} onPress={openSession} />
          ))}
        </View>
      </ScrollView>

      <SessionPlayerModal
        session={activeSession}
        visible={playerVisible}
        onClose={() => setPlayerVisible(false)}
        onComplete={handleComplete}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 14 },
  headerBlock: { gap: 4 },
  title: { fontSize: 26, fontFamily: "DMSerifDisplay_400Regular" },
  sub: { fontSize: 13, fontFamily: "DMSans_400Regular" },
  filterRow: { gap: 8, paddingRight: 4 },
  filterPill: {
    paddingHorizontal: 14, paddingVertical: 8,
    borderWidth: 1.5,
  },
  filterText: { fontSize: 13, fontFamily: "DMSans_500Medium" },
  countLabel: { fontSize: 11, fontFamily: "DMSans_400Regular" },
  grid: { gap: 12 },
});
