import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const MOODS = [
  { value: 1, label: "Rough", icon: "frown" as const, color: "#C96B67", softColor: "#D99C9A", bg: "#FDE9E8" },
  { value: 2, label: "Low",   icon: "meh"   as const, color: "#C98A3A", softColor: "#DDB882", bg: "#FEF1DC" },
  { value: 3, label: "Okay",  icon: "smile" as const, color: "#7874C4", softColor: "#AAA7DC", bg: "#EEEDFA" },
  { value: 4, label: "Good",  icon: "smile" as const, color: "#3A9E7A", softColor: "#80C4A8", bg: "#E3F5EE" },
  { value: 5, label: "Great", icon: "sun"   as const, color: "#2A8068", softColor: "#72B3A4", bg: "#E0F3EE" },
];

function getGreeting(name: string) {
  const hr = new Date().getHours();
  const time = hr < 12 ? "Good morning" : hr < 17 ? "Good afternoon" : "Good evening";
  return name ? `${time}, ${name}` : time;
}

function getDayPhrase() {
  const hr = new Date().getHours();
  if (hr < 12) return "Start your day with intention.";
  if (hr < 17) return "A good moment to pause and breathe.";
  return "Take a moment to wind down.";
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    userName,
    streak,
    sessionsCompleted,
    todayMood,
    logMood,
  } = useApp();

  const [selectedMood, setSelectedMood] = useState<number | null>(todayMood?.value ?? null);
  const [moodLogged, setMoodLogged] = useState(!!todayMood);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 100 : insets.bottom + 100;

  const handleMood = (value: number, label: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedMood(value);
    logMood(value, label);
    setMoodLogged(true);
  };

  const activeMood = MOODS.find((m) => m.value === selectedMood);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingTop: topPad + 24, paddingBottom: bottomPad }]}
      showsVerticalScrollIndicator={false}
    >
      {/* ── GREETING ── */}
      <View style={styles.greetRow}>
        <View style={styles.greetText}>
          <Text style={[styles.greeting, { color: colors.foreground }]}>{getGreeting(userName)}</Text>
          <Text style={[styles.greetSub, { color: colors.mutedForeground }]}>{getDayPhrase()}</Text>
        </View>
        <View style={styles.greetActions}>
          <View style={[styles.streakBadge, { backgroundColor: colors.primaryLight, borderRadius: 14 }]}>
            <Feather name="zap" size={13} color={colors.primary} />
            <Text style={[styles.streakNum, { color: colors.primaryDark }]}>{streak}</Text>
          </View>
          <TouchableOpacity
            style={[styles.settingsBtn, { backgroundColor: colors.card, borderRadius: 12 }]}
            onPress={() => router.push("/settings")}
            activeOpacity={0.75}
          >
            <Feather name="settings" size={18} color={colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </View>

      {/* ── MOOD CHECK-IN ── */}
      <View style={[styles.moodCard, { backgroundColor: colors.card, borderRadius: 20 }]}>
        <Text style={[styles.moodTitle, { color: colors.foreground }]}>
          {moodLogged ? `Feeling ${activeMood?.label?.toLowerCase() ?? "logged"} today` : "How are you feeling?"}
        </Text>
        <View style={styles.moodRow}>
          {MOODS.map((m) => {
            const active = selectedMood === m.value;
            return (
              <TouchableOpacity
                key={m.value}
                style={styles.moodItem}
                onPress={() => handleMood(m.value, m.label)}
                activeOpacity={0.75}
              >
                <View
                  style={[
                    styles.moodCircle,
                    {
                      backgroundColor: m.bg,
                      borderWidth: active ? 2 : 1,
                      borderColor: active ? m.color : m.softColor,
                      transform: [{ scale: active ? 1.12 : 1 }],
                      shadowColor: active ? m.color : "transparent",
                      shadowOpacity: active ? 0.22 : 0,
                      shadowRadius: 8,
                      shadowOffset: { width: 0, height: 3 },
                      elevation: active ? 4 : 0,
                    },
                  ]}
                >
                  <Feather name={m.icon} size={20} color={active ? m.color : m.softColor} />
                </View>
                <Text style={[styles.moodLabel, { color: active ? m.color : m.softColor }]}>
                  {m.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* ── QUICK STATS ── */}
      <View style={styles.statsRow}>
        <View style={[styles.statBox, { backgroundColor: colors.card, borderRadius: 16 }]}>
          <Feather name="zap" size={16} color={colors.primary} />
          <Text style={[styles.statNum, { color: colors.foreground }]}>{streak}</Text>
          <Text style={[styles.statLbl, { color: colors.mutedForeground }]}>day streak</Text>
        </View>
        <View style={[styles.statBox, { backgroundColor: colors.card, borderRadius: 16 }]}>
          <Feather name="headphones" size={16} color={colors.accent} />
          <Text style={[styles.statNum, { color: colors.foreground }]}>{sessionsCompleted}</Text>
          <Text style={[styles.statLbl, { color: colors.mutedForeground }]}>sessions</Text>
        </View>
        <View style={[styles.statBox, { backgroundColor: colors.card, borderRadius: 16 }]}>
          <Feather name="check-circle" size={16} color={colors.primaryDark} />
          <Text style={[styles.statNum, { color: colors.foreground }]}>{moodLogged ? "Done" : "—"}</Text>
          <Text style={[styles.statLbl, { color: colors.mutedForeground }]}>today's log</Text>
        </View>
      </View>

      {/* ── QUICK ACTIONS ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Jump in</Text>

      <TouchableOpacity
        style={[styles.actionRow, { backgroundColor: colors.primary, borderRadius: 18 }]}
        onPress={() => router.push("/(tabs)/chat")}
        activeOpacity={0.85}
      >
        <View style={[styles.actionIcon, { backgroundColor: "rgba(255,255,255,0.18)", borderRadius: 12 }]}>
          <Feather name="message-circle" size={22} color="#fff" />
        </View>
        <View style={styles.actionText}>
          <Text style={styles.actionTitle}>AI Check-in</Text>
          <Text style={styles.actionSub}>Talk through how you're feeling</Text>
        </View>
        <Feather name="chevron-right" size={18} color="rgba(255,255,255,0.7)" />
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.actionRow, { backgroundColor: colors.card, borderRadius: 18 }]}
        onPress={() => router.push("/(tabs)/sessions")}
        activeOpacity={0.85}
      >
        <View style={[styles.actionIcon, { backgroundColor: colors.accentLight, borderRadius: 12 }]}>
          <Feather name="headphones" size={22} color={colors.accent} />
        </View>
        <View style={styles.actionText}>
          <Text style={[styles.actionTitleDark, { color: colors.foreground }]}>Guided Sessions</Text>
          <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>Breathing, sleep & grounding</Text>
        </View>
        <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.actionRow, { backgroundColor: colors.card, borderRadius: 18 }]}
        onPress={() => router.push("/(tabs)/insights")}
        activeOpacity={0.85}
      >
        <View style={[styles.actionIcon, { backgroundColor: colors.primaryLight, borderRadius: 12 }]}>
          <Feather name="bar-chart-2" size={22} color={colors.primaryDark} />
        </View>
        <View style={styles.actionText}>
          <Text style={[styles.actionTitleDark, { color: colors.foreground }]}>Your Insights</Text>
          <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>Mood trends and patterns</Text>
        </View>
        <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },

  greetRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  greetText: { flex: 1, gap: 4 },
  greeting: { fontSize: 28, fontFamily: "DMSerifDisplay_400Regular", lineHeight: 34 },
  greetSub: { fontSize: 13, fontFamily: "DMSans_400Regular" },
  greetActions: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
  streakBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  streakNum: { fontSize: 13, fontFamily: "DMSans_700Bold" },
  settingsBtn: { width: 38, height: 38, alignItems: "center", justifyContent: "center" },

  moodCard: { padding: 20, gap: 16 },
  moodTitle: { fontSize: 15, fontFamily: "DMSans_500Medium" },
  moodRow: { flexDirection: "row", justifyContent: "space-between" },
  moodItem: { alignItems: "center", gap: 6, flex: 1 },
  moodCircle: { width: 48, height: 48, borderRadius: 99, alignItems: "center", justifyContent: "center" },
  moodLabel: { fontSize: 10, fontFamily: "DMSans_500Medium" },

  statsRow: { flexDirection: "row", gap: 10 },
  statBox: { flex: 1, padding: 14, alignItems: "center", gap: 5 },
  statNum: { fontSize: 18, fontFamily: "DMSerifDisplay_400Regular", lineHeight: 22 },
  statLbl: { fontSize: 10, fontFamily: "DMSans_400Regular", textAlign: "center" },

  sectionLabel: {
    fontSize: 11,
    fontFamily: "DMSans_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.7,
    marginBottom: -4,
  },

  actionRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    gap: 14,
  },
  actionIcon: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  actionText: { flex: 1, gap: 2 },
  actionTitle: { fontSize: 15, fontFamily: "DMSans_500Medium", color: "#fff" },
  actionTitleDark: { fontSize: 15, fontFamily: "DMSans_500Medium" },
  actionSub: { fontSize: 12, fontFamily: "DMSans_400Regular", color: "rgba(255,255,255,0.75)" },
});
