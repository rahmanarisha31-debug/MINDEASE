import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const GOALS = [
  { id: "anxiety",    label: "Manage anxiety",    icon: "wind" as const },
  { id: "sleep",      label: "Sleep better",       icon: "moon" as const },
  { id: "stress",     label: "Reduce stress",      icon: "activity" as const },
  { id: "resilience", label: "Build resilience",   icon: "shield" as const },
  { id: "mood",       label: "Track my mood",      icon: "bar-chart-2" as const },
  { id: "mindful",    label: "Be more mindful",    icon: "eye" as const },
];

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { userName, userGoal, streak, sessionsCompleted, updateProfile, clearMoodHistory, resetAll } = useApp();

  const [name, setName] = useState(userName);
  const [goal, setGoal] = useState(userGoal);
  const [saved, setSaved] = useState(false);

  const topPad = Platform.OS === "web" ? 20 : insets.top;
  const bottomPad = Platform.OS === "web" ? 40 : insets.bottom + 24;

  const handleSave = async () => {
    if (!name.trim()) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await updateProfile(name.trim(), goal);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleClearMoods = () => {
    if (Platform.OS === "web") {
      if (window.confirm("Clear all mood history? This cannot be undone.")) clearMoodHistory();
      return;
    }
    Alert.alert("Clear mood history?", "This cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      { text: "Clear", style: "destructive", onPress: clearMoodHistory },
    ]);
  };

  const handleReset = () => {
    if (Platform.OS === "web") {
      if (window.confirm("Reset everything? You'll go back to onboarding.")) {
        resetAll().then(() => router.replace("/onboarding"));
      }
      return;
    }
    Alert.alert("Reset everything?", "All data will be erased. You'll restart from onboarding.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Reset", style: "destructive",
        onPress: async () => { await resetAll(); router.replace("/onboarding"); },
      },
    ]);
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingTop: topPad + 16, paddingBottom: bottomPad }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={[styles.closeBtn, { backgroundColor: colors.card, borderRadius: 12 }]}
          onPress={() => router.back()}
          activeOpacity={0.75}
        >
          <Feather name="x" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Settings</Text>
      </View>

      {/* Stats summary */}
      <View style={[styles.statsCard, { backgroundColor: colors.primaryLight, borderRadius: 18 }]}>
        <View style={styles.statItem}>
          <Text style={[styles.statNum, { color: colors.primaryDark }]}>{streak}</Text>
          <Text style={[styles.statLbl, { color: colors.primaryDark }]}>day streak</Text>
        </View>
        <View style={[styles.statDivider, { backgroundColor: colors.primary }]} />
        <View style={styles.statItem}>
          <Text style={[styles.statNum, { color: colors.primaryDark }]}>{sessionsCompleted}</Text>
          <Text style={[styles.statLbl, { color: colors.primaryDark }]}>sessions done</Text>
        </View>
      </View>

      {/* Profile */}
      <View style={[styles.section, { backgroundColor: colors.card, borderRadius: 18 }]}>
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>Profile</Text>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Your name</Text>
        <TextInput
          style={[
            styles.input,
            {
              backgroundColor: colors.background,
              borderColor: colors.border,
              color: colors.foreground,
              borderRadius: 12,
            },
          ]}
          value={name}
          onChangeText={(t) => { setName(t); setSaved(false); }}
          placeholder="Your first name"
          placeholderTextColor={colors.mutedForeground}
          autoCorrect={false}
        />

        <Text style={[styles.fieldLabel, { color: colors.foreground, marginTop: 4 }]}>Your goal</Text>
        <View style={styles.goalGrid}>
          {GOALS.map((g) => {
            const active = goal === g.id;
            return (
              <TouchableOpacity
                key={g.id}
                style={[
                  styles.goalBtn,
                  {
                    backgroundColor: active ? colors.primaryLight : colors.background,
                    borderColor: active ? colors.primary : colors.border,
                    borderRadius: 12,
                  },
                ]}
                onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setGoal(g.id); setSaved(false); }}
                activeOpacity={0.8}
              >
                <Feather name={g.icon} size={14} color={active ? colors.primary : colors.mutedForeground} />
                <Text style={[styles.goalLabel, { color: active ? colors.primaryDark : colors.foreground }]}>
                  {g.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity
          style={[styles.saveBtn, { backgroundColor: saved ? colors.primaryLight : colors.primary, borderRadius: 14 }]}
          onPress={handleSave}
          disabled={!name.trim()}
          activeOpacity={0.82}
        >
          <Feather name={saved ? "check" : "save"} size={16} color={saved ? colors.primary : "#fff"} />
          <Text style={[styles.saveBtnText, { color: saved ? colors.primary : "#fff" }]}>
            {saved ? "Saved!" : "Save changes"}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Disclaimer */}
      <View style={[styles.disclaimerCard, { backgroundColor: colors.muted, borderRadius: 14 }]}>
        <Feather name="info" size={14} color={colors.mutedForeground} />
        <Text style={[styles.disclaimerText, { color: colors.mutedForeground }]}>
          MindEase is not a substitute for professional mental health treatment. If you are in crisis, please contact a licensed professional or crisis line immediately.
        </Text>
      </View>

      {/* Danger zone */}
      <View style={[styles.section, { backgroundColor: colors.card, borderRadius: 18 }]}>
        <Text style={[styles.sectionTitle, { color: colors.mutedForeground }]}>Data</Text>
        <TouchableOpacity
          style={[styles.dangerBtn, { borderColor: colors.destructive, borderRadius: 12 }]}
          onPress={handleClearMoods}
          activeOpacity={0.8}
        >
          <Feather name="trash-2" size={15} color={colors.destructive} />
          <Text style={[styles.dangerText, { color: colors.destructive }]}>Clear mood history</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.dangerBtn, { borderColor: colors.destructive, borderRadius: 12, backgroundColor: colors.destructiveLight }]}
          onPress={handleReset}
          activeOpacity={0.8}
        >
          <Feather name="alert-triangle" size={15} color={colors.destructive} />
          <Text style={[styles.dangerText, { color: colors.destructive }]}>Reset everything</Text>
        </TouchableOpacity>
      </View>

      <Text style={[styles.version, { color: colors.mutedForeground }]}>MindEase v1.0.0 · Made with ❤️</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 16 },
  header: { flexDirection: "row", alignItems: "center", gap: 14 },
  closeBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 22, fontFamily: "DMSerifDisplay_400Regular" },
  statsCard: { flexDirection: "row", padding: 20, justifyContent: "space-around", alignItems: "center" },
  statItem: { alignItems: "center", gap: 4 },
  statNum: { fontSize: 26, fontFamily: "DMSerifDisplay_400Regular" },
  statLbl: { fontSize: 11, fontFamily: "DMSans_400Regular" },
  statDivider: { width: 1, height: 32, opacity: 0.3 },
  section: { padding: 18, gap: 12 },
  sectionTitle: { fontSize: 11, fontFamily: "DMSans_500Medium", textTransform: "uppercase", letterSpacing: 0.6 },
  fieldLabel: { fontSize: 13, fontFamily: "DMSans_500Medium" },
  input: { padding: 14, fontSize: 15, fontFamily: "DMSans_400Regular", borderWidth: 1 },
  goalGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  goalBtn: { flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1.5 },
  goalLabel: { fontSize: 12, fontFamily: "DMSans_500Medium" },
  saveBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, padding: 15, marginTop: 4 },
  saveBtnText: { fontSize: 15, fontFamily: "DMSans_500Medium" },
  disclaimerCard: { flexDirection: "row", alignItems: "flex-start", gap: 10, padding: 14 },
  disclaimerText: { fontSize: 12, fontFamily: "DMSans_400Regular", lineHeight: 18, flex: 1 },
  dangerBtn: { flexDirection: "row", alignItems: "center", gap: 10, padding: 14, borderWidth: 1.5 },
  dangerText: { fontSize: 14, fontFamily: "DMSans_500Medium" },
  version: { fontSize: 11, fontFamily: "DMSans_400Regular", textAlign: "center" },
});
